
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

 class t1 {
    public static void main(String[] args) throws IOException {
      Scanner in = new Scanner(System.in);
      System.out.println("请输入字典目录");
		String filePath = in.next(); // mulu.txt文件所在路径
		System.out.println("请输入Url，带网站协议头和/");
        String baseUrl = in.next(); // 网站基础URL

        try (FileReader reader = new FileReader(filePath);
		BufferedReader br = new BufferedReader(reader)) {
            String line;
            while ((line = br.readLine()) != null) {
                String urlStr = baseUrl + line; // 拼接完整URL
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("HEAD");

                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    System.out.println(urlStr + " 访问成功！");
                } else {
                    System.out.println(urlStr + " 不存在！（错误码：" + responseCode + "）");
                }
            }
		
			}
    }
	}
	
