
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

 class t10 {
    public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("===请输入要查询的QQ号===");
		Scanner lm1 = new Scanner(System.in);
		System.out.print("Root@HackTools：>");
		String lm = lm1.next();
		String url5 = "https://zy.xywlapi.cc/qqlm?qq="+lm;
		// 打开URL
		URL u5 = new URL(url5);
		// 打开连接
		BufferedReader l = new BufferedReader(new InputStreamReader(u5.openStream()));
		// 读取网页内容
		String line5;
		System.out.println("┈┈┈┈▕▔╲┈┈┈┈\n┈┈┈┈┈▏▕┈┈┈┈\n┈┈┈┈┈▏▕▂▂▂┈\n▂▂▂▂╱┈▕▂▂▂▏\n▉▉▉┈┈┈▕▂▂▂▏\n▉▉▉┈┈┈▕▂▂▂▏\n▔▔▔▔╲▂▕▂▂▂▏\n");
		System.out.println("查询成功");
		while ((line5 = l.readLine()) != null){
			System.out.println("");
			System.out.println(line5);
		}
		// 关闭连接
		l.close();
	}
	}
	
