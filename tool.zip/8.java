
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.io.InputStreamReader;
import java.net.URL;
import java.io.BufferedWriter;
import java.io.FileWriter;

 class t8 {
    public static void main(String[] args) throws IOException, InterruptedException {
		Scanner path = new Scanner(System.in);
		System.out.println("请输入get网址文件路径，输入1启用自带");
		System.out.print("Root@HackTools：>");
		String filePath = path.next();
		if(filePath=="1"){

		}
		System.out.println("请输入代理储存路径(带文件名)，输入1储存在当前目录");
		System.out.print("Root@HackTools：>");
		String Path = path.next();
		
		// 创建BufferedReader对象
		BufferedReader reader = null;
		// 创建FileReader对象
		FileReader fr = new FileReader(filePath);
		// 创建BufferedReader对象
		reader = new BufferedReader(fr);
		// 定义字符串变量
		String line2;
		// 逐行读取文件内容
		while ((line2 = reader.readLine()) != null) {
			// 打印文件内容
			URL proxy = new URL(line2);
			BufferedReader b = new BufferedReader(new InputStreamReader(proxy.openStream()));
			String line1;
			System.out.println("下面是爬取到的代理");
			while ((line1 = b.readLine()) != null)
			{
				line1=line1+"\n";
				System.err.print(line1);
				FileWriter writer = new FileWriter(Path,true);
				BufferedWriter bw = new BufferedWriter(writer);
				bw.write(line1);
				bw.close();
			}
		}}
	}
	
