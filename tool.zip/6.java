
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.io.DataOutputStream;
import java.net.MalformedURLException;
import java.net.Socket;

 class t6 {
    public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("===请输入要查询的QQ号===");
		Scanner qqc = new Scanner(System.in);
		System.out.print("Root@HackTools：>");
		String QQ = qqc.next();
		String url = "https://zy.xywlapi.cc/qqapi?qq="+QQ;
		System.out.println("已对该手机号"+QQ+"进行查询");
		// 打开URL
		URL u = new URL(url);
		// 打开连接
		BufferedReader l = new BufferedReader(new InputStreamReader(u.openStream()));
		// 读取网页内容
		String line;
		while ((line = l.readLine()) != null) {
			System.out.println("");
			System.out.println(line);
		}
		// 关闭连接
		l.close();
                }
	}
	
