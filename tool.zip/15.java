
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

 class t16 {
    public static void main(String[] args) throws IOException, InterruptedException {
		
		Scanner file1 = new Scanner(System.in);
		System.out.println("输入要开放的端口，1000以下选不了 范围1001-65535");
		System.out.print("Root@HackTools：>");
		int PORT = file1.nextInt();
		System.out.println("输入HTML文件目录");
		System.out.print("Root@HackTools：>");
		String filePath1 = file1.next();
		ServerSocket server = new ServerSocket(PORT);
		while (true){
			Socket socket1 = server.accept();
			System.out.println("WebServer is Running...");
			BufferedReader in8 = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
			String line9 = in8.readLine();
			String aString = "HTTP/1.1 200\r\n";
			aString += "Content-Type: text/html;charset=utf-8\r\n\r\n";
			//创建文件对象
			File file = new File(filePath1);
			//创建文件输入流
			FileInputStream fileInputStream = new FileInputStream(file);
			//创建字节数组
			byte[] bytes = new byte[1024];
			//创建StringBuffer 对象
			StringBuffer sb = new StringBuffer();
			//读取内容
			while ( (fileInputStream.read(bytes)) != -1) {  
				sb.append(new String(bytes));
			}
			//打印文件内容 
			System.out.println(sb.toString());
			//关闭输入流
			fileInputStream.close(); 
			aString += sb.toString();
			PrintWriter out = new PrintWriter(socket1.getOutputStream(),true);
			out.println(aString);
			out.close();
			in8.close();
			socket1.close();
		}
				}
        
	}
	
