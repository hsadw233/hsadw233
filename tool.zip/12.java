
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

 class t12 {
    public static void main(String[] args) throws IOException, InterruptedException {
		String dir = System.getProperty("user.dir");
		Random rand=new Random();
		int n2=rand.nextInt(60000)+10001;
		int PORT = n2;
		String filePath1 = dir+"/sxt.html";
		ServerSocket server = new ServerSocket(PORT);
		System.out.println("┈┈┈┈▕▔╲┈┈┈┈\n┈┈┈┈┈▏▕┈┈┈┈\n┈┈┈┈┈▏▕▂▂▂┈\n▂▂▂▂╱┈▕▂▂▂▏\n▉▉▉┈┈┈▕▂▂▂▏\n▉▉▉┈┈┈▕▂▂▂▏\n▔▔▔▔╲▂▕▂▂▂▏\n");
		System.out.println("请访问");
		System.out.println(InetAddress.getLocalHost().getHostAddress()+":"+PORT);
		while (true){
			Socket socket1 = server.accept();
			System.out.println("WebServer is Running...");
			BufferedReader in8 = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
			String line9 = in8.readLine();
			String aString = "HTTP/1.1 200\r\n";
			aString += "Content-Type: text/html;charset=utf-8\r\n\r\n";
			//创建文件对象
			File file = new File(filePath1);
			//创建文件输入流
			FileInputStream fileInputStream = new FileInputStream(file);
			//创建字节数组
			byte[] bytes = new byte[1024];
			//创建StringBuffer 对象
			StringBuffer sb = new StringBuffer();
			//读取内容
			while ( (fileInputStream.read(bytes)) != -1) {  
				sb.append(new String(bytes));
			}
			//打印文件内容 
			System.out.println("有一名访客访问网站");
			//关闭输入流
			fileInputStream.close(); 
			aString += sb.toString();
			PrintWriter out = new PrintWriter(socket1.getOutputStream(),true);
			out.println(aString);
			out.close();
			in8.close();
			socket1.close();

		}
        }
	
	}
	
