
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.io.DataOutputStream;
import java.net.MalformedURLException;
import java.net.Socket;

 class t4 {
    public static void main(String[] args) throws IOException, InterruptedException {
		Scanner input= new Scanner(System.in);
                System.out.println("===请输入要扫描的目标===");
                System.out.print("Root@HackTools：>");
                String ip = input.next();
                //设置目标
                System.out.println("===请输入起始端口===");
                System.out.print("Root@HackTools：>");
                int startPort = input.nextInt();
                //设置起始端口
                System.out.println("===请输入终止端口===");
                System.out.print("Root@HackTools：>");
                int endPort = input.nextInt();
                //设置终止端口
                System.out.println("===请输入扫描间隔===");
                System.out.print("Root@HackTools：>");
                int delayTime = input.nextInt();
                //设置间隔
//进行检测
                for(int port = startPort; port <= endPort; port++) {
                    try {
                        Socket socket = new Socket(ip,port);
                        System.out.println("===端口号："+port+"已被使用===");
                        socket.close();
                    } catch(Exception e) {
                        System.out.println("===端口号："+port+"没有被使用===");
                    }
                    try {
                        Thread.sleep(delayTime);
                    } catch(Exception e) {
                        System.out.println("===延迟出错！===");
                    }
                }
	}}
	
