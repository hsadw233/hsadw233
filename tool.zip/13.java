
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import com.jcraft.jsch.JSch;
import java.util.Scanner;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.Channel;

 class t14 {
    public static void main(String[] args) throws IOException, InterruptedException {
		try { 
			JSch jsch = new JSch(); 
			// 输入连接的服务器地址
			Scanner in7 = new Scanner(System.in);
			System.out.println("===请输入IP===");
			String host = in7.next();
			System.out.println("===请输入用户名===");
			// 输入SSH的用户名
			String user = in7.next(); 
			System.out.println("===请输入密码===");
			// 输入SSH的登录密码 
			String password = in7.next(); 
			String command = ""; 
			// 连接到指定的SSH服务器 
			Session session = jsch.getSession(user, host, 22); 
			// 设置密码 
			session.setPassword(password); 
			session.setConfig("StrictHostKeyChecking",  "no"); 
			System.out.println("Establishing Connection..."); 
			// 连接到服务器 
			session.connect(); 
			System.out.println("Connection established."); 
			// 创建SSH Channel 
			Channel channel = session.openChannel("shell"); 
			// 设置输入流 
			channel.setInputStream(System.in); 
			// 设置输出流 
			channel.setOutputStream(System.out); 
			// 连接 
			channel.connect(); 
			// 循环获取控制台输入的命令 
			BufferedReader reader = new BufferedReader 
			(new InputStreamReader 
			 (System.in)); 
			while (true) { 
				System.out.print("Enter command: "); 
				command = reader.readLine(); 
				if (command.equals("exit")) { 
					break; 
				} 
				// 向Channel写入输入的命令，用\n结尾，表示命令结束 
				channel.getOutputStream().write((command + "\n").getBytes()); 
				channel.getOutputStream().flush(); 
			} 
			// 断开连接 
			channel.disconnect(); 
			session.disconnect(); 

		} catch (Exception e) { 
			System.err.println(e); 
		} 
        }
	}
	
