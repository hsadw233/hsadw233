#!/data/data/com.termux/files/usr/bin/sh

echo "MC - Nukkit"

echo "正在启动基岩服务器"

echo "请注意，外网映射需要自己去购买"


java -Dfile.encoding=utf-8  -jar nukkit-1.0-SNAPSHOT.jar

